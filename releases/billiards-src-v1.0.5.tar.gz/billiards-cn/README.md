# 台球大师 · 离线版

> **修改声明**
> 本作品是开源项目 [tailuge/billiards](https://github.com/tailuge/billiards) 的**衍生作品**，
> 由该项目修改而来，修改日期 **2026 年 8 月 3 日**。
> 原项目版权归 tailuge 及其贡献者所有，依 GNU GPL v3.0 授权。
> 本衍生作品同样依 **GPL-3.0** 发布。

一个全中文、纯离线、无广告的安卓台球游戏。

---

## 引用与致谢

| 项目 | [tailuge/billiards](https://github.com/tailuge/billiards) |
|---|---|
| 作者 | tailuge |
| 协议 | GNU General Public License v3.0 |
| 基线版本 | 0.3.1 |

本项目的**物理引擎、渲染管线、规则判定、本地 AI 对手**等核心实现全部来自上述原始项目。
真实的球体碰撞、旋转、库边反弹与摩擦模型均为原作者的成果。在此向 tailuge 及所有贡献者致谢。

完整的开源声明、修改清单与第三方组件列表见 [`开源声明.md`](开源声明.md)。

---

## 主要改动

**中文本地化** — 菜单、玩法说明、设置、操作介绍、击球按钮、得分板、犯规原因、
胜负结算及斯诺克彩球名称全部汉化；新增集中式文案模块 `src/utils/i18n.ts`。

**移除联网功能** — 移除 WebSocket 多人大厅与消息中继（含 `@tailuge/messaging` 依赖）、
分数上传、遥测统计、崩溃上报、Google Fonts 外链、分享外链、局面图导出、在线分析面板。

**移动端适配** — 新增六档 LOD 画质系统（渲染分辨率 / 抗锯齿 / 球体几何精度）、
设备性能自动检测、刘海屏安全区域适配、横屏布局优化、进球与碰撞震动反馈。

**新增功能** — 中文主菜单、内置操作介绍页、内置游戏设置面板（菜单与游戏内实时同步）、
应用内开源许可与致谢页。

**安卓封装** — Android WebView 原生外壳，不申请任何系统权限。

---

## 目录结构

```
billiards-cn/          游戏本体
  src/                 TypeScript 源码
  dist/                构建产物（可直接用浏览器打开 menu.html）
  webpack.config.js    打包配置
  LICENSE              GPL-3.0 协议全文

billiards-apk/         安卓封装
  AndroidManifest.xml  应用清单（零权限）
  src/                 MainActivity.java
  res/                 图标与字符串资源
```

---

## 构建

### 前端

```bash
cd billiards-cn
yarn install
node_modules/.bin/tsc --noEmit      # 类型检查
node_modules/.bin/webpack           # 打包到 dist/
```

产物为 `dist/` 下的 `index.js`、`three_core.js`、`three_module.js`、`three_examples.js`。
直接用浏览器打开 `dist/menu.html` 即可试玩。

### 安卓 APK

不依赖 Gradle，使用 Android SDK 底层工具链：

```bash
export PATH="$ANDROID_SDK/build-tools/34.0.0:$PATH"
PLATFORM="$ANDROID_SDK/platforms/android-34/android.jar"

# 1. 编译资源
aapt2 compile -o compiled/ res/values/strings.xml
aapt2 compile -o compiled/ res/mipmap-*/ic_launcher.png

# 2. 链接（务必显式指定 SDK 版本，否则会被隐式追加存储/电话权限）
aapt2 link -o base.apk -I "$PLATFORM" --manifest AndroidManifest.xml \
  --min-sdk-version 21 --target-sdk-version 34 --java src/ compiled/*

# 3. 编译并转 dex
javac -source 1.8 -target 1.8 -cp "$PLATFORM" -d obj src/com/tailuge/billiards/cn/*.java
d8 --release --output obj/dex obj/com/tailuge/billiards/cn/*.class

# 4. 组包、对齐、签名
zipalign -p 4 unsigned.apk aligned.apk
apksigner sign --ks release.keystore --min-sdk-version 21 \
  --out billiards-cn.apk aligned.apk
```

---

## 协议

本作品依据 **GNU General Public License v3.0** 发布，与原始项目保持一致。
协议全文见 `billiards-cn/LICENSE`，或访问 https://www.gnu.org/licenses/gpl-3.0.html

你有权自由运行、研究、修改和再分发本作品，但再分发时须遵循同样的 GPL-3.0 条款，
并须提供对应的完整源代码。

本程序不提供任何担保，使用风险由你自行承担。
